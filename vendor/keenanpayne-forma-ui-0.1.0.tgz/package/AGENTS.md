# Working on Forma UI

Forma UI is a CSS design system: a set of design directions (complete looks for a website) that share one contract. `README.md` says what it is and how it's used; `docs/architecture.md` explains how it's built. These are the rules for changing it. The repository is small on purpose: plain CSS in `src/`, Node scripts in `scripts/`, tests in `tests/`, and no preprocessor.

## Always

- Run `npm run validate` before you finish: types, lint, formatting, and the tests, which hold every direction to the contract (`tests/directions.test.ts`), build the package (`tests/build.test.ts`), and run Tailwind over a theme (`tests/tailwind.test.ts`). It must pass, and CI runs it on every push and pull request. A failure names the direction, the rule, and what's missing.
- Never loosen a check in `scripts/lib/foundations.ts`, `tests/`, or `scripts/lib/contrast.ts` to make it pass. Meet the rule instead. If a rule is wrong, change it deliberately, say so in the pull request, and bump the major version if any direction could have relied on it.
- Measure a color before it goes in: `npm run contrast -- "<color>" "<background>"` against everything it sits on, in both schemes and every state (hover, active, visited, selected). Text needs 7:1 (4.5:1 at 24px, or 18.66px bold); borders a control needs, icons, and focus rings need 3:1. `npm run contrast -- <slug>` shows a direction's role pairs.
- Keep the tooling to what's here: Lightning CSS for the build, Vitest for the checks, Node for scripts (run directly, no compile step). Don't add a preprocessor, a bundler, or a framework to the package.
- Keep `README.md`, `docs/`, and `CHANGELOG.md` true. A change to the contract, the exports, the scripts, or a direction's look gets a line in `CHANGELOG.md` under Unreleased.

## Editing one direction

Change only its folder, `src/directions/<slug>/`. Then:

- Keep the role tokens on `:root` (`--<root>-paper`, `-ink`, `-muted`, `-line`, `-surface`, `-accent`, `-focus`, `-selection`, `-selection-ink`, `-font-display`, `-font-body`, `-font-mono`) and both color schemes, identically, as `docs/tokens.md` describes. An alias of a token the direction already has is fine (`--mc-paper: var(--mc-void)`), but a scope that re-declares the tokens a role aliases re-declares the role too.
- Prefix every class, custom property, and `@keyframes` name with the root class, and scope every selector under it, print styles included. Several directions load at once in the demo and in the site that uses them.
- Paint the page in `-paper` with `body:has(.<root>)`, draw focus rings in `-focus`, color `::selection` with `-selection` and `-selection-ink`, and stop motion under `prefers-reduced-motion: reduce` with one rule on `.<root> *`.
- Keep what the accessibility bar asks of markup the direction styles: targets of 44 by 44px (a link inside a sentence is exempt), text blocks at a line height of 1.5 and 80 characters a line or fewer, never justified, no sideways scrolling at 320px, a focus ring of at least 2px at 3:1 against what's behind it, and nothing fixed or sticky covering a focused element.
- A change to the markup a component expects is a change to its sample too: update `samples/components/<section>.html` (and the pages that use it), so the demo and the recipes stay true. The samples are the contract for the classes.
- Fonts live in `direction.json` (`fonts`), nowhere else. The stylesheet names the families; the manifest says where they load from.
- Say in your summary what no tool checks: hover and focus states, anything drawn over an image or gradient, motion, 200% text, a screen reader pass.

## Starting a direction

`npm run new -- <slug> [--root <prefix>] ["Display name"]` copies Wireframe, the unstyled baseline, renaming its root throughout, so the new direction passes every check from the start. Then fill in `direction.json`, restyle the stylesheet, rework the samples as the look needs, and check it with `npm run demo` and `npm run check`. `docs/creating-a-direction.md` has the whole process, including how to think about motifs versus the shared vocabulary.

## Changing the foundation

The base reset (`src/base.css`), the role list (`ROLES` in `scripts/lib/foundations.ts`), the sample vocabulary (`COMPONENTS` and `PAGES` in `scripts/lib/samples.ts`), the Tailwind mapping (`tailwindTheme()` in `scripts/build.ts`), and the exports map in `package.json` are shared by every direction and every consumer. Changing any of them is a breaking change unless it only adds: a new role means every direction needs it (the check lists them), and a new sample section means every direction needs a file for it.

## The samples

`src/directions/<slug>/samples/` is rendered markup, not hand-written: the site the directions were designed for writes it from its own pages (`npm run forma:samples` in keenanpayne.com, after `npm run build` there). Edit a sample by hand only for a direction that has no other source; otherwise change the source and re-run the export. Prettier leaves the folder alone (`.prettierignore`).

## Publishing

`npm version <patch|minor|major>` then `npm publish --access public`; `prepublishOnly` runs `npm run validate` and the build first. Move the Unreleased notes in `CHANGELOG.md` under the new version before you tag. `docs/versioning.md` says what each bump means.
