# Forma UI

A CSS design system of complete **design directions**: each one a finished look for a website, shipped as a stylesheet you can drop into any page, a theme for Tailwind CSS v4, and the markup recipes that go with it. Every direction is built on the same foundation, so they can be swapped, compared, and extended, and every one is held to the same bar: twelve named role tokens in light and dark, and WCAG 2.2 AAA.

Forma UI is a library, not a framework: it brings styles and a contract, and leaves your markup, your build, and your framework to you. It was extracted from the design lab behind [keenanpayne.com](https://keenanpayne.com/lab/), where each direction renders the whole site.

| Direction | Look | Root class |
| --- | --- | --- |
| Wireframe | The baseline: plain semantic HTML in system type. Every direction starts as a copy of it. | `.wireframe` |
| Monograph | Grayscale broadsheet. Light serif display over tiny monospace copy, hairline and double rules. | `.mg` |
| Mech | Mecha command HUD. Amber panels with corner brackets on a black lattice, live readouts, hazard stripes. | `.mc` |
| Portal | Early-2000s console-maker web portal. A periwinkle bezel, halftone nav bars, pixel-font buttons, a pixel mascot. | `.pt` |
| Stipple | Olive ink on white inside a hairline frame, with every image rendered in stippled dither. | `.st` |
| Gridline | Hairline rails and cells with type doing the work, inverted bands, and violet light rays. | `.gl` |
| Neon | Cyberpunk night city after the rain: neon tube lettering over a generated skyline. Light mode is dawn. | `.neon` |

Run `npm run demo` to see each one's tokens, every component with its markup, and its full pages.

## Install

### Plain HTML, no build

```html
<link
  rel="stylesheet"
  href="https://unpkg.com/@keenanpayne/forma-ui@0.1.0/dist/css/gridline.min.css"
/>
<!-- Gridline's web fonts, from its manifest -->
<link
  rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Instrument+Serif:ital@0;1&family=IBM+Plex+Mono:wght@400;500&display=swap"
/>

<body>
  <div class="gl">…</div>
</body>
```

Each direction's stylesheet includes the base reset and is scoped to its root class, so nothing applies until you put that class on the element that wraps the page. The fonts a direction loads are listed in `dist/directions.json` (and `src/directions/<slug>/direction.json`).

### npm

```bash
npm install @keenanpayne/forma-ui
```

```js
import "@keenanpayne/forma-ui/gridline.css"; // base + Gridline, flattened and prefixed
import "@keenanpayne/forma-ui/gridline.min.css"; // the same, minified
import "@keenanpayne/forma-ui/base.css"; // the reset alone
import "@keenanpayne/forma-ui/forma.css"; // base + every direction
```

With Vite, React Router, Next.js, Astro, SvelteKit, or any bundler that understands CSS imports, that's the whole integration. To link rather than bundle (React Router's `links`, say), import the URL: `import href from "@keenanpayne/forma-ui/gridline.css?url"`.

The manifests ship too:

```js
import { directions, getDirection } from "@keenanpayne/forma-ui";
getDirection("gridline").fonts; // the stylesheets to load before it
getDirection("gridline").roles.dark.paper; // "#0d0c12"
```

### Tailwind CSS v4

```css
@import "tailwindcss";
@import "@keenanpayne/forma-ui/gridline.css";
@import "@keenanpayne/forma-ui/tailwind/gridline.css";
```

The second import is the direction's components; the third maps its role tokens into Tailwind's theme, so `bg-paper`, `text-ink`, `text-muted`, `border-line`, `bg-surface`, `text-accent`, `outline-focus`, `font-display`, `font-body`, and `font-mono` (and their variants, `bg-paper/50`, `hover:text-accent`) follow the direction, in both schemes. It's declared `@theme inline`, so the utilities read the direction's own custom properties and keep up wherever it re-scopes them (Gridline's inverted bands). See [docs/installing.md](docs/installing.md) for layering the direction's CSS under Tailwind's utilities.

## What's in a direction

```
src/directions/<slug>/
├── direction.json      # slug, name, root class, summary, reference, date, fonts
├── <slug>.css          # The stylesheet, nested as written, scoped to .<root>
└── samples/
    ├── components/     # One HTML file per component section: the markup recipes
    └── pages/          # One HTML file per kind of page, whole
```

The **contract** every direction meets is small, and `npm run check` enforces it:

- The twelve **role tokens** on `:root`, prefixed with its root class: `--<root>-paper`, `-ink`, `-muted`, `-line`, `-surface`, `-accent`, `-focus`, `-selection`, `-selection-ink`, `-font-display`, `-font-body`, `-font-mono`. Everything else is the direction's own.
- **Both color schemes**, declared the same way everywhere: `:root` for the default, then the other twice, identically, under `@media (prefers-color-scheme: …)` with `:root:not([data-theme="…"])` and under `:root[data-theme="…"]` for a site's own switch.
- **AAA contrast** between the roles: text at 7:1, the accent and focus ring at 3:1, in both schemes.
- The page painted in `-paper`, the focus ring drawn in `-focus`, selection in `-selection`, and every animation stopped under `prefers-reduced-motion`.
- **Its prefix on everything**: every class, custom property, and keyframe, and every selector scoped under its root, so several directions can load at once.
- A **sample** for every component section and every page.

[docs/tokens.md](docs/tokens.md) and [docs/components.md](docs/components.md) spell these out; [docs/creating-a-direction.md](docs/creating-a-direction.md) walks through building one; [docs/architecture.md](docs/architecture.md) explains why it's shaped this way. Agents start at [AGENTS.md](AGENTS.md).

## Scripts

```bash
npm run demo                # Build and serve the demo at http://localhost:4545
npm run build               # Build dist/ (CSS, Tailwind themes, directions.json)
npm run watch               # Rebuild dist/ on every change to src/
npm run check               # Hold every direction to the contract
npm test                    # The checks, plus the build and Tailwind tests
npm run contrast -- "#6b6b6b" "#fff"   # Measure two colors against AAA
npm run contrast -- gridline           # A direction's role pairs, both schemes
npm run new -- <slug> [--root <prefix>] ["Name"]   # Start a direction from Wireframe
npm run validate            # Types, lint, formatting, tests (CI runs this)
```

Requirements: Node.js 22.18 or later (24 is pinned in `.node-version`). The build is one tool, [Lightning CSS](https://lightningcss.dev/), which flattens the nesting, lowers media ranges, adds vendor prefixes, and minifies. There is no preprocessor: the source is plain, modern CSS.

## Versioning

Releases follow [semantic versioning](https://semver.org/); [CHANGELOG.md](CHANGELOG.md) lists what changed in each. What counts as breaking, and how a release is cut, is in [docs/versioning.md](docs/versioning.md).

## License

[MIT](LICENSE)
