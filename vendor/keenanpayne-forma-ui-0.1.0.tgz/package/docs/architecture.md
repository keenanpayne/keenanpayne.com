# Architecture

How Forma UI is designed and built, and why. Read this before changing anything shared; `creating-a-direction.md` is enough for adding a look.

## The idea

A **design direction** is a complete visual language for a website: type, color, spacing, ornament, and the look of every part a site needs, from the header to a form field. Forma UI holds several of them over one foundation, so that:

- a site can pick one and get a finished look, not a kit of parts to assemble;
- directions can be compared side by side, because they describe the same things;
- anyone can add one, following the same rules, and have it checked the same way;
- every one is accessible to the same standard, measured rather than hoped.

The directions came from the design lab at keenanpayne.com, where each one renders the whole site from the same content and information architecture. That discipline (content comes from props, never from the skin) is what made them portable: a direction is _only_ how things look, so its stylesheet and markup can leave the site behind.

## Layers

| Layer | Lives in | Owns |
| --- | --- | --- |
| Base | `src/base.css` | The reset every direction sits on: border-box sizing, no body margin, antialiased type. Nothing else. |
| Contract | `scripts/lib/foundations.ts`, `scripts/lib/contrast.ts`, `docs/tokens.md` | The twelve role tokens, both schemes, AAA contrast between the roles, the page color, focus, selection, reduced motion, and the prefix rule. |
| Vocabulary | `scripts/lib/samples.ts`, `docs/components.md` | The component sections and page kinds every direction shows: what a direction has to have a look for. |
| Directions | `src/directions/<slug>/` | A manifest, a stylesheet, and samples. How it looks. |
| Build | `scripts/build.ts`, `scripts/lib/css.ts` | Source to package: flat, prefixed, minified CSS; Tailwind themes; `directions.json`. |
| Checks | `tests/` | Every direction against the contract and the vocabulary; the build against the exports map; Tailwind against a theme. |
| Demo | `scripts/demo.ts`, `scripts/demo/` | Static pages that show every direction's tokens, components with markup, and full pages. |
| Docs | `README.md`, `AGENTS.md`, `docs/` | For people and agents: what it is, how to use it, how to extend it. |

There is no registry: a direction exists when its folder has a `direction.json`. The build, the checks, and the demo all read the folders (`listDirections()` in `scripts/lib/directions.ts`), so adding a direction is adding a folder.

## Why CSS first

The most portable thing a design system can ship is a stylesheet. A React component library would bind every consumer to React, and to one content model; a Web Components library would bring a runtime and its own trade-offs. A stylesheet with documented markup works in a static HTML file, a CMS template, and every framework alike, and it's the form the directions already took.

So the unit of a direction is **CSS plus markup recipes**. The recipes (`samples/`) show the HTML each component expects: copy the markup, keep the classes, change the words. A framework wraps that markup in whatever component model it likes; keenanpayne.com wraps it in React.

What this means for consumers: directions don't share a class vocabulary. Gridline's card is `.gl-cell.gl-work`; Wireframe's is `.wireframe-card`. The _sections_ are shared (every direction has cards, a page header, forms, a shell), the markup is each direction's own, because the looks are structurally different (Portal's bezel, Mech's panels). Switching directions means switching markup, which is what keenanpayne.com does with a template per direction. What _is_ shared, and stable across directions, is the token contract; a site that builds its own parts with the Tailwind theme or the role tokens gets a consistent palette and type in any direction.

## The token contract

Every direction names the same twelve roles on `:root`, prefixed with its root class (see `tokens.md`). The prefix is what lets several directions load on one page (the demo, the lab) without colliding, and it's why the roles are `--gl-paper` rather than `--paper`.

Tokens are declared three times: on `:root` for the default scheme, and for the other scheme both under `@media (prefers-color-scheme: …)` guarded by `:root:not([data-theme="…"])` and under `:root[data-theme="…"]`. The media query follows the visitor's system; the attribute lets a site offer its own switch that wins over it. The two blocks must match, and the check compares them.

The contract stops there on purpose. Spacing scales, type scales, radii, and shadows differ so much between directions that naming them would either constrain the looks or mean nothing. A direction has as many tokens of its own as it likes (Gridline has 285), all prefixed.

## Tailwind

Tailwind CSS v4 is configured in CSS, with `@theme` declaring the variables its utilities are generated from, in known namespaces (`--color-*`, `--font-*`). The build writes one theme file per direction mapping each role into those namespaces:

```css
@theme inline {
  --color-paper: var(--gl-paper);
  …
  --font-display: var(--gl-font-display);
}
```

`inline` matters: the generated utility reads the direction's own property (`background-color: var(--gl-paper)`) rather than a copy on `:root`, so it follows the direction wherever the direction re-scopes its tokens (an inverted band, a dark panel). The theme file is generated, not written, so it can't drift from the role list; a direction can add more theme variables in a `tailwind.css` of its own, appended at build time.

## The build

One tool, [Lightning CSS](https://lightningcss.dev/), does everything between the source and the package: it resolves nesting, lowers media range syntax, adds vendor prefixes for the browsers in `TARGETS` (spring 2023 and later), and minifies. The source is plain CSS written with native nesting; modern browsers could load it as is, and the built files exist for the rest and for size.

For each direction the build writes `dist/css/<slug>.css` (the base, then the direction) and a minified twin, plus `dist/css/forma.css` with every direction, `dist/tailwind/<slug>.css`, and `dist/directions.json` with every manifest and the role values the build read from the CSS, also as `dist/index.js` for importing. The exports map in `package.json` gives each a short subpath (`@keenanpayne/forma-ui/gridline.css`) and exposes `src/` whole, so the nested source and the samples are there to read in `node_modules`.

The checks flatten with the same function the build uses (`flatten()` in `scripts/lib/css.ts`), so what they measure is what ships.

## The checks

`tests/directions.test.ts` is the contract made executable. For each direction: the manifest is sound; the stylesheet compiles with no warnings; every role is on `:root` with the right prefix; both schemes are declared and match; the roles reach AAA contrast with each other in both schemes; the page, focus ring, selection, and reduced motion are handled; everything is prefixed; and every sample is present. `tests/build.test.ts` builds into a scratch folder and reads it back against the exports map. `tests/tailwind.test.ts` runs Tailwind itself over a theme and asserts the utilities it generates.

A failure names the direction, the rule, and what's missing, so a person or an agent can fix it without reading the others. The rules only get stricter: a check is never loosened to pass.

What the checks can't see is listed in `accessibility.md`: hover and focus states, motion, 200% text, a screen reader pass. The site the directions came from runs a browser audit (axe plus its own checks) over every page of every direction; a direction built here alone should be put through the same before it's called done.

## The demo

`npm run demo` builds static HTML into `demo/` and serves it. The index lists every direction with its palette and typefaces; each direction's page shows its tokens (read from the CSS), its typefaces, and every component section inside a stage carrying the root class, with a markup panel listing each recipe's HTML; and each full page is the direction's own page with a small bar for switching direction, page, and color scheme. It needs no framework to build or run, and the output deploys anywhere static files do.

## Where the samples come from

The samples are rendered markup. keenanpayne.com renders every direction's style guide and sample pages to static HTML at build time; `npm run forma:samples` there extracts the direction's own markup from those pages (dropping the lab's chrome and scripts, pointing links at the demo or the live site) and writes it into this repository. Re-running it after a change to a direction's templates keeps the recipes true. A direction built here without a site behind it writes its samples by hand, starting from Wireframe's, and they're checked the same way.

The sample content is the site's own: its posts, its work, its author. The directions never type any of it; it all arrives through props, which is what the lab's source check enforces and what made the extraction clean.

## What isn't here, and why

- **Framework components.** They'd bind the package to a framework and a content model. The site keeps its React templates and imports the stylesheets from here.
- **A JavaScript API for the checks.** The check library (`scripts/lib/`) is plain TypeScript run by Node, not published. Publishing it would add runtime dependencies (PostCSS, Color.js) to a CSS package. If a second consumer needs it, it can become a separate package.
- **Shared component classes across directions.** See "Why CSS first".
- **Icons, images, and generated art.** Each direction's illustrations are drawn by the site's code at render time and arrive in the samples as inline SVG, which is why some sample files are large. The stylesheets reference nothing outside themselves.
