# Versioning

Forma UI follows [semantic versioning](https://semver.org/). A site pins a version and updates on its own schedule; `CHANGELOG.md` says what each version changed, in the [Keep a Changelog](https://keepachangelog.com/) shape.

## What the numbers mean

A **major** version changes something a site could have depended on:

- a role token, the way schemes are declared, or the prefix rule;
- a class name, a token, or the markup a recipe expects, in any direction;
- a direction removed, or renamed;
- the base reset;
- a package subpath in the exports map, or the Tailwind mapping;
- the browser targets of the build moving forward past a browser a site supports.

A **minor** version adds without changing:

- a new direction;
- a new component, variant, or token in a direction, with existing markup rendering as before;
- a new section or page in the sample vocabulary (every direction gains a sample);
- a new file or subpath in the package.

A **patch** version fixes within the contract: a contrast ratio brought up to AAA, a layout bug, a typo in a sample, the build producing smaller or more correct CSS for the same source.

A visual change to a direction that keeps every class and recipe working is a minor version when it's a new look for a part, and a patch when it's a correction. When in doubt, say what changed in the changelog and lean toward the higher bump.

Before 1.0 the usual exception applies: minor versions may break, and the changelog says when they do.

## Cutting a release

1. Move the entries under **Unreleased** in `CHANGELOG.md` under the new version and date.
2. `npm version <patch|minor|major>`: bumps `package.json`, commits, and tags `v<version>`.
3. `npm publish --access public`: `prepublishOnly` runs `npm run validate` and `npm run build` first, so a release that fails a check never ships.
4. `git push --follow-tags`.

The package is scoped (`@keenanpayne/forma-ui`), so the first publish needs `--access public`; after that it's remembered. `.github/workflows/release.yml` publishes the same way when a `v*` tag is pushed, given an `NPM_TOKEN` secret, with provenance.

What's in the tarball is `files` in `package.json`: `dist/`, `src/` (the source stylesheets, manifests, and samples), `docs/`, `AGENTS.md`, and `CHANGELOG.md`. The demo isn't; deploy `demo/` from a build instead.

## In a site

A site that renders with a direction should treat it like any dependency: pin it (`"@keenanpayne/forma-ui": "0.1.0"` or `^0.1.0` once 1.0 is out), read the changelog, update, and look at the pages. keenanpayne.com's own conformance checks and browser audit run against the installed version, which is the test that matters there.

To work on a direction from a site before it's released, link the repositories (`npm link` here, `npm link @keenanpayne/forma-ui` there) and run `npm run watch` here; the site then reads `dist/` straight from this checkout.
