# Creating a direction

A direction is a complete look: a stylesheet, a manifest, and a sample of every component and page. This is the whole process, for a person or an agent. It assumes you've read `tokens.md` and `components.md`.

## 1. Start from Wireframe

```bash
npm run new -- <slug> [--root <prefix>] ["Display name"]
npm run new -- neo-brutal --root nb "Neo Brutal"
```

This copies `src/directions/wireframe/`, the unstyled baseline, into `src/directions/<slug>/`, renaming its root class throughout (the stylesheet and every sample), and writes a manifest to fill in. Wireframe meets every requirement in plain HTML, so the copy passes `npm run check` before you've changed a line, and shows you what every section and page has to have.

Pick the **slug** for URLs and file names (`neo-brutal`) and the **root** for class names (`nb`): short, since it prefixes everything. Both are kebab-case; the root must be unused by any other direction.

## 2. Fill in the manifest

`src/directions/<slug>/direction.json`:

```json
{
  "slug": "neo-brutal",
  "name": "Neo Brutal",
  "root": "nb",
  "summary": "What it looks like, in a sentence or two. Written for the demo's index.",
  "reference": "What inspired it",
  "date": "2026-10-25",
  "fonts": ["https://fonts.googleapis.com/css2?family=…&display=swap"]
}
```

`fonts` is every stylesheet to load before the direction's: Google Fonts URLs, usually, with just the weights and styles the direction uses. The stylesheet names the families in its font tokens; the manifest says where they load from. Leave it empty for system type.

## 3. Set the tokens

At the top of `<slug>.css`, name the twelve roles on `:root` and override them for the other scheme twice, identically (see `tokens.md`). Add the direction's own tokens beside them, all prefixed.

Measure every color before it goes in:

```bash
npm run contrast -- "#504e59" "#fcfcfb"   # text on paper: 7:1
npm run contrast -- "#393db0" "#fff"      # accent on surface: 3:1
npm run contrast -- neo-brutal            # the role pairs, both schemes
npm run contrast -- neo-brutal --all      # every color token, as text, on paper and surface
```

Text needs 7:1 (4.5:1 at 24px, or 18.66px bold); borders a control needs, icons, and focus rings need 3:1, against everything they sit on, in both schemes and every state (hover, active, visited, selected). A color that only ever fills a decoration needs nothing, but say so in a comment.

## 4. Restyle

Work through the stylesheet section by section against the demo:

```bash
npm run watch          # rebuilds dist/ as you save
npm run demo           # in another terminal; reload the page to see changes
```

Open `http://localhost:4545/<slug>/` for every component in one place, and `http://localhost:4545/<slug>/home.html` for the pages.

Rules the checks hold you to:

- **Prefix everything** with the root class: every class, custom property, and `@keyframes` name, and scope every selector under `.<root>` (or a `.<root>-…` class, or `:root`). Several directions load on one page in the demo and in the site that uses them, so nothing may leak.
- **The page** is painted in `-paper` by `body:has(.<root>)`; **focus rings** are drawn in `-focus` by a `:focus-visible` rule, 2px or more; **selection** uses `-selection` and `-selection-ink`; and **motion stops** under `prefers-reduced-motion: reduce` with one rule on `.<root> *`.
- **Targets** are 44 by 44px (a link inside a sentence is exempt); **text blocks** have a line height of 1.5 and 80 characters a line or fewer, never justified; **nothing scrolls sideways** at 320px; nothing fixed or sticky covers a focused element.

And rules of craft:

- Write the stylesheet to the markup in the samples. Where the look needs different markup (a wrapper for a frame, a span for an underline), change the sample too, and keep the semantics: landmarks, headings, `alt`, labels, `aria-current`.
- Keep Wireframe's structure for the Shell: skip link, name linking home, one `<nav>` with the current item marked, the clock, `<main id>`, and a footer with copyright, social links, and feed.
- Nesting is plain CSS nesting (`&`); the build flattens it. Range media queries (`(width >= 640px)`) are fine; the build lowers them. No Sass, no mixins.
- Motifs are yours: ornament, illustration, animation, labels in the direction's voice, another presentation of the same content. Put a new part or variant in the `motifs` sample (or the section it belongs to) so the demo shows it.

## 5. Rework the samples

`samples/components/*.html` and `samples/pages/*.html` are the direction's markup recipes and what the demo renders. Edit them to match the markup your stylesheet expects: new wrappers, the direction's own labels, extra parts. Keep every file, and keep the kit's captions (`.sg-specimen`, `.sg-caption`, `.sg-specimen__body`) around each part so the demo can list it as a recipe.

The content in them is the sample site's. Don't replace it with your own; a direction is how things look, not what they say.

## 6. Check

```bash
npm run check      # the contract, this direction and the others
npm run validate   # plus types, lint, and formatting
```

A failure names the direction, the rule, and what's missing. Fix the direction; never the rule.

Then check by hand what no tool here can (`accessibility.md`): hover and focus states and anything drawn over an image or gradient; motion that starts on its own; content that appears on hover; flashing; 200% text and text spacing; a screen reader pass; headings that say what's under them. Say which you checked when you hand the direction over.

## 7. Add it to the lists

- A row in `README.md`'s table.
- A line in `CHANGELOG.md` under Unreleased (a new direction is a minor version).

Nothing else registers it: the build, the checks, and the demo find it by its folder.

## Doing it in a site

If the direction is for a site that renders the whole page in it (as keenanpayne.com does), the loop runs there: link this repository into the site (`npm link` here, then `npm link @keenanpayne/forma-ui` there), build the templates against `npm run watch` here, and export the samples back from the site's rendered pages when they settle. The site's own checks (its feature conformance and browser audit) cover what this repository can't.

## For agents

Everything above applies. In addition:

- Read `tokens.md`, `components.md`, and Wireframe's stylesheet and samples before writing CSS. Wireframe is the specification of what every section contains.
- Work in one folder, `src/directions/<slug>/`. Changing `src/base.css`, `scripts/`, or `tests/` is changing the foundation for every direction, and is a separate, deliberate change.
- Measure colors with `npm run contrast` as you choose them, not after. Keep a note of each pair's ratio in a CSS comment where it isn't obvious.
- Run `npm run check` often; its failures are written to be acted on one at a time.
- Describe the direction in `direction.json`'s `summary` as it looks, not as it was built: it's what a person reads to choose it.
- Finish with `npm run validate`, and in your summary list the hand checks from `accessibility.md` you made and what you saw.
