# Components

What a direction has a look for, and how to use its markup.

## The vocabulary

Every direction shows the same **sections**, each a group of components with a job. They're `COMPONENTS` in `scripts/lib/samples.ts`, and a direction has a sample for each (`samples/components/<id>.html`):

| Section | id | What it holds |
| --- | --- | --- |
| Type scale | `type` | Display, page title, lede, section heading, item heading, body, eyebrow, label, meta: every style of type, measured in the demo |
| Motifs | `motifs` | Ornament, icons, rules, and the flourishes that make the direction recognizable |
| Imagery | `imagery` | How photos, covers, and portraits are treated |
| Page header | `pageHeader` | The eyebrow, title, and lede that open a page |
| Buttons & links | `actions` | Calls to action, buttons, and links, in each of their variants |
| Labels & tags | `labels` | Eyebrows, badges, chips, tags, and metadata |
| Sections & panels | `surfaces` | The containers, rules, and dividers that structure a page |
| Cards | `cards` | Work, writing, and services as cards |
| Lists & tables | `lists` | Post lists, ledgers, facts, and tables |
| Testimonials | `quotes` | Quotes with the person they came from |
| Forms | `forms` | A contact form's fields (text, email, textarea, choices), and a one-field newsletter sign-up |
| Wayfinding | `wayfinding` | Previous and next, back links, contents, switches, and other ways around |
| Prose | `prose` | An article body with every element Markdown can produce: headings, lists, quotes, code, tables, callouts, figures, footnotes |
| Shell | `shell` | The header (name, navigation, a clock), the main landmark, and the footer (copyright, social links, feed), around a placeholder |

And every direction has the same **pages**, whole (`samples/pages/<id>.html`): `home`, `portfolio`, `case-study`, `writing-archive`, `blog-post`, `tutorial-post`, `type-archive`, `about`, `services`, `service`, `testimonials`, `contact`, `project-inquiry`, `page`, and `not-found`. They're `PAGES` in the same file.

The sections are what a personal or studio site needs. A direction can have more parts than the sections name (a motif is the direction's own); it can't have fewer.

## Using a recipe

Open the demo (`npm run demo`), pick a direction, find the component, and open its **Markup** panel: each recipe is one part's HTML, pretty-printed, with a Copy button. The same HTML is in `src/directions/<slug>/samples/components/<section>.html`, which ships in the package, so from a project it's at `node_modules/@keenanpayne/forma-ui/src/directions/<slug>/samples/`.

Then:

1. Put the direction's root class on the element that wraps the page (`<div class="gl">`), once. Every rule is scoped under it.
2. Paste the recipe and change the words, the links, and the images. Keep the classes and the structure: the stylesheet selects on both (`.gl-cells__grid > .gl-cell`).
3. Keep the semantics the recipe has (`<nav aria-label>`, `<h2>` where it has one, `alt` on images, `<time datetime>`). The accessibility bar was met with them.
4. Where a recipe has text the stylesheet depends on for size (a 44px target, an 80-character measure), keep something there.

A direction's parts are built to compose the way its pages do; the full pages in `samples/pages/` show the arrangement. When a part looks wrong on its own, look at how a page wraps it (a section, a band, a grid).

## What's in a sample

A component sample is the section as the style guide laid it out: a grid of captioned specimens.

```html
<div class="sg-grid">
  <div class="sg-specimen">
    <div class="sg-caption">
      <span class="sg-caption__label">Work card</span>
      <span class="sg-caption__note"
        >Cover, name, lede, industry and years</span
      >
    </div>
    <div class="sg-specimen__body">
      <!-- the part itself -->
    </div>
  </div>
</div>
```

The `sg-` classes are the demo's captions and grid, styled by `scripts/demo/demo.css`, not by the direction; the recipe is what's inside `.sg-specimen__body` (or `.sg-type__sample`, for a type sample), which is what the markup panel shows. Nothing in a sample is the direction's unless it carries the direction's prefix.

A page sample is the whole page: the direction's outermost element with the root class, and everything inside it. Links in the samples point at the other sample pages (`./about.html`) where the demo has them, and at the live site otherwise.

## The classes

Each direction names its classes in its own voice, prefixed with its root: block, element, and modifier in the `.gl-cell`, `.gl-cell__title`, `.gl-cell--pad` manner, mostly. Directions don't share class names; see `architecture.md` for why. What they share is the sections above, the role tokens, and the structure every Shell has:

- a skip link to the main landmark;
- the site name linking home;
- one `<nav>` for the primary navigation, with `aria-current="page"` on the current item;
- a clock that opens a weather popover (the lab's; a site can leave it out);
- `<main id="…">`;
- a `<footer>` with a copyright line, the social links, and a feed link.

## Prose

The `prose` section is styled against the HTML a Markdown pipeline produces: headings with anchor links (`a.header-anchor`), lists, blockquotes, `<pre><code class="language-…">` with Prism's token classes, tables, figures with captions, footnotes (`.footnotes`, `.footnote-ref`), and a few callouts (`.note`, `.tip`, `.notice`, `.question`, `.tldr`, `.further-reading`, each with an `.icon`). The sample shows one of each; match its structure for the ones you use.

## Adding to the vocabulary

A new section or page kind is a change to every direction: add it to `COMPONENTS` or `PAGES`, and `npm run check` lists each direction missing its sample. Do it when every direction should have a look for the thing, not for a part only one direction has (that's a motif, and it goes in that direction's `motifs` sample).
