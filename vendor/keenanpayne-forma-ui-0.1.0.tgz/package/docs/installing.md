# Installing

Forma UI is CSS. Every way of using it comes down to loading one stylesheet, putting one class on the element that wraps the page, and loading the direction's fonts.

## What to load

For a direction with slug `<slug>` (and root class `<root>`):

| File | Package subpath | What it is |
| --- | --- | --- |
| `dist/css/<slug>.css` | `@keenanpayne/forma-ui/<slug>.css` | The base reset and the direction, flattened and prefixed for browsers from spring 2023 on |
| `dist/css/<slug>.min.css` | `@keenanpayne/forma-ui/<slug>.min.css` | The same, minified |
| `dist/css/base.css` | `@keenanpayne/forma-ui/base.css` | The reset alone |
| `dist/css/forma.css` | `@keenanpayne/forma-ui/forma.css` | The base and every direction, each scoped to its own root |
| `dist/tailwind/<slug>.css` | `@keenanpayne/forma-ui/tailwind/<slug>.css` | The direction's role tokens as a Tailwind v4 `@theme` |
| `dist/directions.json` | `@keenanpayne/forma-ui/directions.json` | Every manifest with its palette and file paths |
| `src/directions/<slug>/<slug>.css` | `@keenanpayne/forma-ui/src/directions/<slug>/<slug>.css` | The source, nested as written |
| `src/directions/<slug>/samples/` | `@keenanpayne/forma-ui/src/directions/<slug>/samples/` | The markup recipes |

The fonts are in the manifest (`fonts`), as stylesheet URLs to load before the direction's. The direction's stylesheet names the families with fallbacks, so it degrades to system type if they don't load.

## Plain HTML

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="color-scheme" content="light dark" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=Instrument+Serif:ital@0;1&family=IBM+Plex+Mono:wght@400;500&display=swap"
    />
    <link
      rel="stylesheet"
      href="https://unpkg.com/@keenanpayne/forma-ui@0.1.0/dist/css/gridline.min.css"
    />
  </head>
  <body>
    <div class="gl">
      <!-- the page, built from Gridline's recipes -->
    </div>
  </body>
</html>
```

Pin the version in the URL. [unpkg](https://unpkg.com/) and [jsDelivr](https://www.jsdelivr.com/) (`https://cdn.jsdelivr.net/npm/@keenanpayne/forma-ui@0.1.0/dist/css/gridline.min.css`) both serve npm packages; or copy the file into your project.

`<meta name="color-scheme" content="light dark">` lets the browser paint form controls and scrollbars to match. To offer your own switch, set `data-theme="light"` or `"dark"` on `<html>`; remove it to follow the system.

## npm, with a bundler

```bash
npm install @keenanpayne/forma-ui
```

Then import the stylesheet where your bundler expects CSS. The import resolves through the package's exports map, so the subpath is the same everywhere.

**Vite** (and anything built on it: React Router, SvelteKit, Astro, Nuxt, SolidStart):

```js
import "@keenanpayne/forma-ui/gridline.css";
```

To link it rather than bundle it, which keeps it cacheable on its own and lets a server render the `<link>`:

```js
import href from "@keenanpayne/forma-ui/gridline.css?url";
```

**React Router** (framework mode): return it from a route's `links`, or render `<link rel="stylesheet" href={href} precedence="default">`. keenanpayne.com does the latter, with the fonts from the manifest in front:

```tsx
import direction from "@keenanpayne/forma-ui/directions/gridline.json";
import stylesheet from "@keenanpayne/forma-ui/gridline.css?url";

const stylesheets = [...direction.fonts, stylesheet];
```

**Next.js**: import it in `app/layout.tsx` (or `pages/_app.tsx`); add the fonts with `next/font` or a `<link>` in the layout's `<head>`.

**Astro**: import it in a layout's frontmatter, or add a `<link>` to the public URL.

**webpack** with `css-loader`: `import "@keenanpayne/forma-ui/gridline.css"`.

In every case, add the root class to the element that wraps the page, and load the fonts.

## Tailwind CSS v4

Tailwind v4 is configured in CSS. In the stylesheet you hand to Tailwind:

```css
@import "tailwindcss";
@import "@keenanpayne/forma-ui/gridline.css";
@import "@keenanpayne/forma-ui/tailwind/gridline.css";
```

The second line brings the direction's components; the third declares its role tokens as theme variables, so these utilities exist and follow the direction in both schemes:

| Utility | Reads |
| --- | --- |
| `bg-paper`, `text-paper`, `border-paper`, … | `--<root>-paper` |
| `text-ink`, `bg-ink`, … | `--<root>-ink` |
| `text-muted` | `--<root>-muted` |
| `border-line`, `divide-line`, `outline-line` | `--<root>-line` |
| `bg-surface` | `--<root>-surface` |
| `text-accent`, `bg-accent`, `border-accent` | `--<root>-accent` |
| `outline-focus`, `ring-focus` | `--<root>-focus` |
| `bg-selection`, `text-selection-ink` | `--<root>-selection`, `-selection-ink` |
| `font-display`, `font-body`, `font-mono` | `--<root>-font-display`, `-body`, `-mono` |

Opacity modifiers work (`bg-paper/50`), as do variants (`hover:text-accent`, `focus-visible:outline-focus`). No `dark:` variants are needed: the tokens change on their own.

**Layering.** Unlayered CSS beats layered CSS, so by default the direction's rules win over Tailwind's utilities on the same element. If you'd rather utilities win (to nudge a direction's part with `mt-8`, say), import the direction into Tailwind's components layer:

```css
@import "@keenanpayne/forma-ui/gridline.css" layer(components);
```

Then `base < components < utilities`, as Tailwind orders them. Either way, the direction's `:root` tokens and `body:has()` rule apply as written.

**Preflight.** Tailwind's preflight resets more than the direction's base does (it zeroes heading sizes and margins, for one). The directions set what they need explicitly, so they render the same with or without it; if a part looks off under preflight, it's a part relying on a browser default, and worth a report.

## Several directions at once

Every rule in a direction is scoped under its root class, every token and keyframe is prefixed, and `forma.css` holds all of them, so two directions can be on one page: one wrapping each region, or swapped by changing one class. `:root` tokens from every loaded direction coexist, since they're prefixed. The demo index does this to show every direction's typefaces on one page.

## Updating

Pin a version and read `CHANGELOG.md` before moving. Within a major version, class names, tokens, and the markup each recipe expects don't change; see `versioning.md`.
