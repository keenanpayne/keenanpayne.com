# Accessibility

Every direction is held to [WCAG 2.2 AAA](https://www.w3.org/TR/WCAG22/). Part of that is measured here, before anything renders; the rest is measured in a browser, and some of it by hand.

## Checked here

`npm run check` holds each direction's stylesheet to:

| Check | Criterion | What it measures |
| --- | --- | --- |
| `css.contrast` | 1.4.6 Contrast (Enhanced), 1.4.11 Non-text Contrast, 2.4.13 Focus Appearance | The role tokens against each other in both schemes: text at 7:1, the accent and the focus ring at 3:1 (see `tokens.md`) |
| `css.focus` | 2.4.7 Focus Visible, 2.4.13 | A `:focus-visible` rule drawing an outline in the focus token |
| `css.schemes` | 1.4.3, 1.4.6 (in both schemes) | Light and dark both declared, the same way, with the page and its text changing |
| `css.reducedMotion` | 2.3.3 Animation from Interactions | Every animation and transition stopped under `prefers-reduced-motion: reduce` |
| `css.selection` | 1.4.6 | Selected text colored with the selection tokens, which are measured |

`npm run contrast` measures any color pair the same way, for choosing colors before they go in.

## Checked in a browser

The site the directions were designed for audits every page of every direction, light and dark, on a desktop and a 320px phone, with [axe](https://github.com/dequelabs/axe-core) (every WCAG 2.0–2.2 rule at A, AA, and AAA) and checks of its own for what axe doesn't measure:

- targets of 44 by 44px (2.5.5 Target Size, Enhanced), a link inside a sentence excepted;
- a line height of 1.5, lines of 80 characters or fewer, and no justified text (1.4.8 Visual Presentation);
- no sideways scrolling at 320px (1.4.10 Reflow);
- tabbing through every page, a focus ring of at least 2px at 3:1 (2.4.13) that nothing fixed or sticky covers (2.4.12 Focus Not Obscured).

Those are the rules the directions' stylesheets were written to, and the markup in the samples passed them. A direction built here alone should be put through the same before it's called done: the demo's pages are plain HTML, so axe's browser extension, Lighthouse, or a Playwright script with `@axe-core/playwright` can audit `http://localhost:4545/<slug>/<page>.html`.

## Checked by hand

No tool can check these; do them for any change to how a direction looks or behaves, and say which you did:

1. **Hover and focus states**, and anything drawn over an image, a gradient, or a pseudo-element's fill: their contrast, focus rings included. The checks measure flat colors only.
2. **Motion that starts on its own** (2.2.2 Pause, Stop, Hide): it stops within five seconds, or can be paused, or lives in something the visitor opened and can close.
3. **Content on hover or focus** (1.4.13): it can be dismissed with Escape, hovered over, and stays until then.
4. **Flashing** (2.3.2): nothing flashes more than three times a second.
5. **200% text size**, and WCAG's text spacing (1.4.12): nothing is cut off or overlaps.
6. **A screen reader** (VoiceOver, ⌘F5): the page reads in order, and every control says what it is and does.
7. **Copy**: headings that say what's under them (2.4.10), abbreviations spelled out (3.1.4), plain language (3.1.5).

## In your own markup

The recipes carry the semantics they were audited with. When you build from them, keep: landmarks (`<header>`, `<nav aria-label>`, `<main>`, `<footer>`); one `<h1>` per page and headings in order; `alt` on images (empty for decoration); `<label>`s on fields; `aria-current="page"` on the current navigation item; `<time datetime>`; a skip link to `<main>`. The stylesheet gives targets their size and text its measure only on the elements the recipes use, so a new element in a new place needs its own look.
