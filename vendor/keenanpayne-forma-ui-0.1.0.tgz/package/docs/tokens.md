# Tokens

Every direction names the same twelve **roles** as custom properties on `:root`, prefixed with its root class. That's the whole shared contract for color and type; everything else is the direction's own.

## The roles

| Role | Token | For |
| --- | --- | --- |
| `paper` | `--<root>-paper` | The page's background |
| `ink` | `--<root>-ink` | Body text |
| `muted` | `--<root>-muted` | Secondary text: dates, captions, metadata |
| `line` | `--<root>-line` | Rules and borders |
| `surface` | `--<root>-surface` | Panels, cards, and other raised fills |
| `accent` | `--<root>-accent` | The direction's highlight (its ink, in one without a highlight) |
| `focus` | `--<root>-focus` | The focus ring |
| `selection` | `--<root>-selection` | Selected text's background |
| `selection-ink` | `--<root>-selection-ink` | Selected text |
| `font-display` | `--<root>-font-display` | Display type: titles and headings |
| `font-body` | `--<root>-font-body` | Body type |
| `font-mono` | `--<root>-font-mono` | Monospace: code, and labels in directions that use it |

`<root>` is the direction's root class from its manifest: `gl` for Gridline, so `--gl-paper`. The list is `ROLES` in `scripts/lib/foundations.ts`.

An alias of a token the direction already has is fine, and usual:

```css
:root {
  --gl-raised: #fff;
  --gl-accent: #393db0;

  --gl-surface: var(--gl-raised);
  --gl-focus: var(--gl-accent);
}
```

A custom property resolves where it's declared, so a scope that re-declares the tokens a role aliases must re-declare the role too (an inverted band that sets `--gl-raised` again sets `--gl-surface` again).

## Contrast

In both schemes, the roles reach WCAG 2.2 AAA contrast with each other:

| Pair | Minimum | Criterion |
| --- | --- | --- |
| `ink` on `paper`, `ink` on `surface` | 7:1 | 1.4.6 Contrast (Enhanced) |
| `muted` on `paper`, `muted` on `surface` | 7:1 | 1.4.6 |
| `selection-ink` on `selection` | 7:1 | 1.4.6 |
| `accent` on `paper`, `accent` on `surface` | 3:1 | 1.4.11 Non-text Contrast |
| `focus` on `paper`, `focus` on `surface` | 3:1 | 2.4.13 Focus Appearance |

A translucent color is measured laid over the one beneath it, the way the page paints it. A system color (`Highlight`) is the browser's to keep legible and isn't measured. `npm run contrast -- <slug>` prints the table; `npm run contrast -- "<color>" "<background>"` measures any two colors.

The accent is held to 3:1 because it marks things (borders, icons, rules). Where a direction sets _text_ in its accent, that text needs 7:1 (4.5:1 if it's at least 24px, or 18.66px bold) against what it sits on: measure it.

## Light and dark

Tokens are declared on `:root` for the direction's default scheme, then overridden for the other scheme twice, identically:

```css
:root {
  --gl-paper: #fcfcfb;
  --gl-ink: #100f16;
  …
}

/* The visitor's system preference */
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --gl-paper: #0d0c12;
    --gl-ink: #f4f3f8;
    …
  }
}

/* A site's own switch, which wins over the preference */
:root[data-theme="dark"] {
  --gl-paper: #0d0c12;
  --gl-ink: #f4f3f8;
  …
}
```

A direction that's dark by default (Mech) does the same the other way round: `:root` dark, then `prefers-color-scheme: light` with `:root:not([data-theme="dark"])`, and `:root[data-theme="light"]`. `paper` and `ink` must change between the schemes; the check compares the two override blocks declaration by declaration.

To offer a switch on a site, set `data-theme="light"` or `"dark"` on `<html>` and remove it for "follow the system". The demo's switch does exactly that. Set `color-scheme` alongside the tokens where the direction's form controls and scrollbars should follow.

## What the page does with them

Beyond naming the roles, every direction:

- paints the page in its paper: `body:has(.<root>) { background: var(--<root>-paper); }`;
- draws focus rings in `-focus`: a `:focus-visible` rule with an `outline` in `var(--<root>-focus)`, at least 2px, and 3:1 against what's behind it;
- colors selection: `::selection { background: var(--<root>-selection); color: var(--<root>-selection-ink); }`;
- stops motion when asked: under `@media (prefers-reduced-motion: reduce)`, one rule on `.<root> *` (and `::before`, `::after`) setting `animation: none !important; transition: none !important`.

## Reading the tokens

`dist/directions.json` (and `import { directions } from "@keenanpayne/forma-ui"`) carries each role's value in each scheme, with `var()` aliases resolved, so a site can read a direction's palette without parsing its CSS:

```json
{
  "slug": "gridline",
  "root": "gl",
  "scheme": "light",
  "roles": {
    "light": { "paper": "#fcfcfb", "ink": "#100f16", … },
    "dark": { "paper": "#0d0c12", "ink": "#f4f3f8", … }
  }
}
```

The parser that reads them (`scripts/lib/tokens.ts`) expects the three blocks above, at the top level of the stylesheet, with `:root {` at the start of a line.

## In Tailwind

`dist/tailwind/<slug>.css` maps the roles into Tailwind v4's theme namespaces: the color roles as `--color-<role>` and the font roles as `--font-display`, `--font-body`, `--font-mono`. So the utilities are `bg-paper`, `text-ink`, `text-muted`, `border-line`, `bg-surface`, `text-accent`, `outline-focus` (or `ring-focus`), `bg-selection`, `text-selection-ink`, `font-display`, `font-body`, `font-mono`, with every variant Tailwind gives a color (`bg-paper/50`, `hover:text-accent`, `dark:` is unnecessary, since the tokens change on their own). Note `font-mono` replaces Tailwind's default of the same name, which is the point.

## Other tokens

A direction has as many other tokens as it likes, for its own type scale, spacing, motifs, and states, all prefixed with its root (`--gl-ray`, `--mc-amber`). The demo lists every token it finds on `:root`, colors as swatches in both schemes and the rest in a table. None of them is part of the contract, and a site shouldn't depend on one across directions.
