# Changelog

All notable changes to Forma UI are listed here, newest first, in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) shape. Versions follow [semantic versioning](https://semver.org/); see `docs/versioning.md` for what each bump means.

## [Unreleased]

## [0.1.0] - 2026-10-25

The first release: the seven directions of keenanpayne.com's design lab, extracted into a package.

### Added

- Directions: Wireframe (the baseline), Monograph, Mech, Portal, Stipple, Gridline, and Neon, each a stylesheet scoped to its root class, a manifest, and samples of every component section and page.
- The token contract: twelve role tokens per direction, both color schemes, AAA contrast between the roles, the page color, focus ring, selection, and reduced motion, and a prefix on everything, held by `npm run check`.
- The build: Lightning CSS from `src/` to `dist/css/<slug>.css` (base plus direction, flattened and prefixed, with a minified twin), `dist/css/forma.css` with every direction, a Tailwind CSS v4 `@theme inline` file per direction, and `dist/directions.json` (also `index.js`) with every manifest and palette.
- Package subpaths: `@keenanpayne/forma-ui/<slug>.css`, `/<slug>.min.css`, `/base.css`, `/forma.css`, `/tailwind/<slug>.css`, `/directions.json`, `/directions/<slug>.json`, and `/src/*`.
- The demo (`npm run demo`): every direction's tokens, typefaces, components with their markup, and full pages, as static HTML.
- Scripts: `build`, `watch`, `check`, `contrast`, `new`, `demo`.
- Documentation for people and agents: `README.md`, `AGENTS.md`, and `docs/` (architecture, installing, tokens, components, creating a direction, accessibility, versioning).

[Unreleased]: https://github.com/keenanpayne/forma-ui/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/keenanpayne/forma-ui/releases/tag/v0.1.0
